import 'package:flutter/material.dart';


class CameraPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Center(
          child: Text("Camera page"),
        )
    );
  }
}