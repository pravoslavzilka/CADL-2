import 'package:flutter/material.dart';

class AccountPage extends StatelessWidget {
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
          child: Text("Account page")
      ),
    );
  }
}