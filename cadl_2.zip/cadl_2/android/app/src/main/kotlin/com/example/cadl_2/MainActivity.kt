package com.example.cadl_2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
